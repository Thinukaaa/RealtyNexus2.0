# RealtyNexus2.0
Real Estate Website ChatBot.


#Project: RealtyNexus Demo — 1-Page Website + Accurate Chatbot
#Stack: Python (Flask) + OpenAI API (LLM + Embeddings)




